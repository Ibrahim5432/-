import os
import json
import logging
from datetime import datetime
from flask import Flask, jsonify, render_template, send_from_directory
from flask_cors import CORS

# إعداد التسجيل
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# إعداد تطبيق Flask
app = Flask(__name__)
CORS(app)  # تفعيل CORS للسماح بالوصول من أي مصدر

# المسار للملف الذي يخزن فيه بيانات أسعار الصرف
EXCHANGE_RATES_FILE = 'exchange_rates.json'

# بيانات افتراضية للعرض
DEFAULT_DATA = {
    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    "currencies": {
        "USD": {"sell": 9600, "buy": 9500, "sellChange": 0, "buyChange": 0},
        "EUR": {"sell": 10500, "buy": 10400, "sellChange": 0, "buyChange": 0},
        "TRY": {"sell": 246, "buy": 242, "sellChange": 0, "buyChange": 0},
        "GBP": {"sell": 12200, "buy": 12100, "sellChange": 0, "buyChange": 0},
        "EGP": {"sell": 192, "buy": 188, "sellChange": 0, "buyChange": 0},
        "SAR": {"sell": 2562, "buy": 2532, "sellChange": 0, "buyChange": 0},
        "JOD": {"sell": 13570, "buy": 13420, "sellChange": 0, "buyChange": 0},
        "AED": {"sell": 2614, "buy": 2584, "sellChange": 0, "buyChange": 0},
        "KWD": {"sell": 31500, "buy": 31200, "sellChange": 0, "buyChange": 0}
    },
    "gold": {
        "gold18": 1850000,
        "gold21": 2160000,
        "gold24": 2470000,
        "ounce": 19500000
    }
}

# دالة لتحديث البيانات من مصدر خارجي (سيتم استبدالها لاحقاً بالبيانات الحقيقية)
def update_exchange_rates():
    try:
        # في الإصدار النهائي، سيتم استبدال هذا بجلب البيانات من قناة التلغرام
        # لكن للعرض التجريبي، سنستخدم البيانات الافتراضية مع تغييرات عشوائية
        import random
        
        data = DEFAULT_DATA.copy()
        data["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # إضافة تغييرات عشوائية للعملات
        for currency in data["currencies"]:
            change = random.randint(-50, 50)
            data["currencies"][currency]["sell"] += change
            data["currencies"][currency]["buy"] += change
            data["currencies"][currency]["sellChange"] = change
            data["currencies"][currency]["buyChange"] = change
        
        # إضافة تغييرات عشوائية للذهب
        for gold_type in data["gold"]:
            data["gold"][gold_type] += random.randint(-10000, 10000)
        
        # حفظ البيانات في ملف
        with open(EXCHANGE_RATES_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        logger.info("تم تحديث بيانات أسعار الصرف")
        return data
    except Exception as e:
        logger.error(f"خطأ في تحديث البيانات: {e}")
        return DEFAULT_DATA

# مسارات API
@app.route('/api/exchange-rates', methods=['GET'])
def get_exchange_rates():
    try:
        # إذا كان الملف موجوداً، قراءة البيانات منه
        if os.path.exists(EXCHANGE_RATES_FILE):
            with open(EXCHANGE_RATES_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
        else:
            # إذا لم يكن الملف موجوداً، تحديث البيانات وإنشاء الملف
            data = update_exchange_rates()
        
        return jsonify(data)
    except Exception as e:
        logger.error(f"خطأ في قراءة البيانات: {e}")
        return jsonify({'error': 'حدث خطأ أثناء قراءة البيانات'}), 500

# مسار لتحديث البيانات يدوياً (للاختبار فقط)
@app.route('/api/update', methods=['GET'])
def update_data():
    try:
        data = update_exchange_rates()
        return jsonify({"status": "success", "message": "تم تحديث البيانات بنجاح", "data": data})
    except Exception as e:
        logger.error(f"خطأ في تحديث البيانات: {e}")
        return jsonify({'error': 'حدث خطأ أثناء تحديث البيانات'}), 500

# مسار الصفحة الرئيسية
@app.route('/')
def index():
    return render_template('index.html')

# مسار للملفات الثابتة
@app.route('/static/<path:path>')
def static_files(path):
    return send_from_directory('static', path)

# دالة لتحديث البيانات دورياً
def schedule_updates():
    import threading
    import time
    
    def update_periodically():
        while True:
            update_exchange_rates()
            # تحديث كل 30 دقيقة
            time.sleep(30 * 60)
    
    # بدء خيط منفصل للتحديث الدوري
    update_thread = threading.Thread(target=update_periodically)
    update_thread.daemon = True
    update_thread.start()

if __name__ == '__main__':
    # إنشاء ملف بيانات افتراضي إذا لم يكن موجوداً
    if not os.path.exists(EXCHANGE_RATES_FILE):
        with open(EXCHANGE_RATES_FILE, 'w', encoding='utf-8') as f:
            json.dump(DEFAULT_DATA, f, ensure_ascii=False, indent=2)
        logger.info(f"تم إنشاء ملف بيانات افتراضي: {EXCHANGE_RATES_FILE}")
    
    # بدء جدولة التحديثات الدورية
    schedule_updates()
    
    # بدء تطبيق Flask
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
