import os
import json
import logging
import threading
import time
from datetime import datetime
from flask import Flask, jsonify, render_template, send_from_directory
from flask_cors import CORS

# استيراد مستخرج التلغرام
from telegram_extractor import load_data, save_data, update_periodically

# إعداد التسجيل
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# إعداد تطبيق Flask
app = Flask(__name__)
CORS(app)  # تفعيل CORS للسماح بالوصول من أي مصدر

# المسار للملف الذي يخزن فيه بيانات أسعار الصرف
EXCHANGE_RATES_FILE = 'exchange_rates.json'

# مسارات API
@app.route('/api/exchange-rates', methods=['GET'])
def get_exchange_rates():
    try:
        # قراءة البيانات من ملف
        data = load_data()
        return jsonify(data)
    except Exception as e:
        logger.error(f"خطأ في قراءة البيانات: {e}")
        return jsonify({'error': 'حدث خطأ أثناء قراءة البيانات'}), 500

# مسار لتحديث البيانات يدوياً (للاختبار فقط)
@app.route('/api/update', methods=['GET'])
def update_data():
    try:
        # قراءة البيانات الحالية
        current_data = load_data()
        
        # إضافة تغييرات عشوائية للعملات (للعرض التجريبي فقط)
        import random
        
        for currency_code in current_data["currencies"]:
            change = random.randint(-50, 50)
            current_data["currencies"][currency_code]["sell"] += change
            current_data["currencies"][currency_code]["buy"] += change
            current_data["currencies"][currency_code]["sellChange"] = change
            current_data["currencies"][currency_code]["buyChange"] = change
        
        # إضافة تغييرات عشوائية للذهب
        for gold_type in current_data["gold"]:
            current_data["gold"][gold_type] += random.randint(-10000, 10000)
        
        # تحديث الطابع الزمني
        current_data["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # حفظ البيانات المحدثة
        save_data(current_data)
        
        return jsonify({"status": "success", "message": "تم تحديث البيانات بنجاح", "data": current_data})
    except Exception as e:
        logger.error(f"خطأ في تحديث البيانات: {e}")
        return jsonify({'error': 'حدث خطأ أثناء تحديث البيانات'}), 500

# مسار الصفحة الرئيسية
@app.route('/')
def index():
    return render_template('index.html')

# مسار للملفات الثابتة
@app.route('/static/<path:path>')
def static_files(path):
    return send_from_directory('static', path)

if __name__ == '__main__':
    # بدء تحديث البيانات في الخلفية
    update_periodically()
    
    # بدء تطبيق Flask
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
