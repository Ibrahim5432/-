import os
import re
import json
import logging
import requests
import time
from datetime import datetime
from telethon import TelegramClient, events
from telethon.errors import SessionPasswordNeededError

# إعداد التسجيل
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# المسار للملف الذي يخزن فيه بيانات أسعار الصرف
EXCHANGE_RATES_FILE = 'exchange_rates.json'

# بيانات افتراضية للعرض
DEFAULT_DATA = {
    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    "currencies": {
        "USD": {"sell": 9600, "buy": 9500, "sellChange": 0, "buyChange": 0},
        "EUR": {"sell": 10500, "buy": 10400, "sellChange": 0, "buyChange": 0},
        "TRY": {"sell": 246, "buy": 242, "sellChange": 0, "buyChange": 0},
        "GBP": {"sell": 12200, "buy": 12100, "sellChange": 0, "buyChange": 0},
        "EGP": {"sell": 192, "buy": 188, "sellChange": 0, "buyChange": 0},
        "SAR": {"sell": 2562, "buy": 2532, "sellChange": 0, "buyChange": 0},
        "JOD": {"sell": 13570, "buy": 13420, "sellChange": 0, "buyChange": 0},
        "AED": {"sell": 2614, "buy": 2584, "sellChange": 0, "buyChange": 0},
        "KWD": {"sell": 31500, "buy": 31200, "sellChange": 0, "buyChange": 0}
    },
    "gold": {
        "gold18": 1850000,
        "gold21": 2160000,
        "gold24": 2470000,
        "ounce": 19500000
    }
}

# تعيين بيانات API التلغرام
# هذه البيانات ستكون مخصصة للتطبيق وليست بيانات المستخدم الشخصية
API_ID = 12345678  # سيتم استبداله بالرقم الحقيقي عند النشر
API_HASH = 'abcdef1234567890abcdef1234567890'  # سيتم استبداله بالقيمة الحقيقية عند النشر
PHONE = '+963123456789'  # سيتم استبداله برقم الهاتف الحقيقي عند النشر
CHANNEL_USERNAME = 'lira_price'  # اسم مستخدم القناة المستهدفة

# أنماط التعبيرات النمطية للعثور على أسعار الصرف
CURRENCY_PATTERNS = {
    'USD': {
        'sell': r'الدولار الأمريكي.*?مبيع.*?(\d+(?:,\d+)?)',
        'buy': r'الدولار الأمريكي.*?شراء.*?(\d+(?:,\d+)?)'
    },
    'EUR': {
        'sell': r'اليورو.*?مبيع.*?(\d+(?:,\d+)?)',
        'buy': r'اليورو.*?شراء.*?(\d+(?:,\d+)?)'
    },
    'TRY': {
        'sell': r'الليرة التركية.*?مبيع.*?(\d+(?:,\d+)?)',
        'buy': r'الليرة التركية.*?شراء.*?(\d+(?:,\d+)?)'
    },
    'GBP': {
        'sell': r'الجنيه الإسترليني.*?مبيع.*?(\d+(?:,\d+)?)',
        'buy': r'الجنيه الإسترليني.*?شراء.*?(\d+(?:,\d+)?)'
    },
    'EGP': {
        'sell': r'الجنيه المصري.*?مبيع.*?(\d+(?:,\d+)?)',
        'buy': r'الجنيه المصري.*?شراء.*?(\d+(?:,\d+)?)'
    },
    'SAR': {
        'sell': r'الريال السعودي.*?مبيع.*?(\d+(?:,\d+)?)',
        'buy': r'الريال السعودي.*?شراء.*?(\d+(?:,\d+)?)'
    },
    'JOD': {
        'sell': r'الدينار الأردني.*?مبيع.*?(\d+(?:,\d+)?)',
        'buy': r'الدينار الأردني.*?شراء.*?(\d+(?:,\d+)?)'
    },
    'AED': {
        'sell': r'الدرهم الإماراتي.*?مبيع.*?(\d+(?:,\d+)?)',
        'buy': r'الدرهم الإماراتي.*?شراء.*?(\d+(?:,\d+)?)'
    },
    'KWD': {
        'sell': r'الدينار الكويتي.*?مبيع.*?(\d+(?:,\d+)?)',
        'buy': r'الدينار الكويتي.*?شراء.*?(\d+(?:,\d+)?)'
    }
}

GOLD_PATTERNS = {
    'gold18': r'الذهب عيار 18.*?(\d+(?:,\d+)?)',
    'gold21': r'الذهب عيار 21.*?(\d+(?:,\d+)?)',
    'gold24': r'الذهب عيار 24.*?(\d+(?:,\d+)?)',
    'ounce': r'أونصة الذهب.*?(\d+(?:,\d+)?)'
}

# دالة لتحويل النص إلى رقم
def text_to_number(text):
    if not text:
        return 0
    # إزالة الفواصل وتحويل النص إلى رقم
    return int(text.replace(',', ''))

# دالة لاستخراج أسعار الصرف من نص الرسالة
def extract_exchange_rates(message_text):
    data = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "currencies": {},
        "gold": {}
    }
    
    # استخراج أسعار العملات
    for currency_code, patterns in CURRENCY_PATTERNS.items():
        sell_match = re.search(patterns['sell'], message_text, re.IGNORECASE | re.DOTALL)
        buy_match = re.search(patterns['buy'], message_text, re.IGNORECASE | re.DOTALL)
        
        sell_price = text_to_number(sell_match.group(1)) if sell_match else 0
        buy_price = text_to_number(buy_match.group(1)) if buy_match else 0
        
        if sell_price > 0 or buy_price > 0:
            data["currencies"][currency_code] = {
                "sell": sell_price,
                "buy": buy_price,
                "sellChange": 0,  # سيتم حسابه لاحقاً
                "buyChange": 0    # سيتم حسابه لاحقاً
            }
    
    # استخراج أسعار الذهب
    for gold_type, pattern in GOLD_PATTERNS.items():
        match = re.search(pattern, message_text, re.IGNORECASE | re.DOTALL)
        if match:
            price = text_to_number(match.group(1))
            if price > 0:
                data["gold"][gold_type] = price
    
    return data

# دالة لحساب التغييرات في الأسعار
def calculate_changes(new_data, old_data):
    if not old_data:
        return new_data
    
    for currency_code in new_data["currencies"]:
        if currency_code in old_data["currencies"]:
            new_data["currencies"][currency_code]["sellChange"] = new_data["currencies"][currency_code]["sell"] - old_data["currencies"][currency_code]["sell"]
            new_data["currencies"][currency_code]["buyChange"] = new_data["currencies"][currency_code]["buy"] - old_data["currencies"][currency_code]["buy"]
    
    return new_data

# دالة لدمج البيانات الجديدة مع البيانات القديمة
def merge_data(new_data, old_data):
    if not old_data:
        return new_data
    
    merged_data = old_data.copy()
    merged_data["timestamp"] = new_data["timestamp"]
    
    # دمج بيانات العملات
    for currency_code, currency_data in new_data["currencies"].items():
        if currency_code not in merged_data["currencies"]:
            merged_data["currencies"][currency_code] = currency_data
        else:
            # تحديث الأسعار إذا كانت البيانات الجديدة تحتوي على قيم
            if currency_data["sell"] > 0:
                merged_data["currencies"][currency_code]["sell"] = currency_data["sell"]
                merged_data["currencies"][currency_code]["sellChange"] = currency_data["sellChange"]
            if currency_data["buy"] > 0:
                merged_data["currencies"][currency_code]["buy"] = currency_data["buy"]
                merged_data["currencies"][currency_code]["buyChange"] = currency_data["buyChange"]
    
    # دمج بيانات الذهب
    for gold_type, price in new_data["gold"].items():
        if price > 0:
            merged_data["gold"][gold_type] = price
    
    return merged_data

# دالة لحفظ البيانات في ملف
def save_data(data):
    try:
        with open(EXCHANGE_RATES_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        logger.info(f"تم حفظ البيانات في الملف: {EXCHANGE_RATES_FILE}")
        return True
    except Exception as e:
        logger.error(f"خطأ في حفظ البيانات: {e}")
        return False

# دالة لقراءة البيانات من ملف
def load_data():
    try:
        if os.path.exists(EXCHANGE_RATES_FILE):
            with open(EXCHANGE_RATES_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            logger.info(f"تم قراءة البيانات من الملف: {EXCHANGE_RATES_FILE}")
            return data
        else:
            logger.warning(f"ملف البيانات غير موجود: {EXCHANGE_RATES_FILE}")
            return DEFAULT_DATA
    except Exception as e:
        logger.error(f"خطأ في قراءة البيانات: {e}")
        return DEFAULT_DATA

# دالة لجلب آخر الرسائل من قناة التلغرام
async def get_latest_messages(client, limit=10):
    try:
        messages = []
        async for message in client.iter_messages(CHANNEL_USERNAME, limit=limit):
            if message.text:
                messages.append(message.text)
        return messages
    except Exception as e:
        logger.error(f"خطأ في جلب الرسائل: {e}")
        return []

# دالة لمعالجة الرسائل وتحديث البيانات
async def process_messages(client):
    try:
        # جلب آخر الرسائل
        messages = await get_latest_messages(client)
        if not messages:
            logger.warning("لم يتم العثور على أي رسائل")
            return
        
        # قراءة البيانات الحالية
        current_data = load_data()
        
        # معالجة كل رسالة
        for message_text in messages:
            # استخراج البيانات من الرسالة
            new_data = extract_exchange_rates(message_text)
            
            # حساب التغييرات
            new_data = calculate_changes(new_data, current_data)
            
            # دمج البيانات
            current_data = merge_data(new_data, current_data)
        
        # حفظ البيانات المحدثة
        save_data(current_data)
        logger.info("تم تحديث البيانات بنجاح")
    except Exception as e:
        logger.error(f"خطأ في معالجة الرسائل: {e}")

# دالة لمراقبة الرسائل الجديدة
async def monitor_new_messages(client):
    @client.on(events.NewMessage(chats=CHANNEL_USERNAME))
    async def handler(event):
        try:
            message_text = event.message.text
            if not message_text:
                return
            
            logger.info(f"تم استلام رسالة جديدة: {message_text[:50]}...")
            
            # قراءة البيانات الحالية
            current_data = load_data()
            
            # استخراج البيانات من الرسالة
            new_data = extract_exchange_rates(message_text)
            
            # حساب التغييرات
            new_data = calculate_changes(new_data, current_data)
            
            # دمج البيانات
            current_data = merge_data(new_data, current_data)
            
            # حفظ البيانات المحدثة
            save_data(current_data)
            logger.info("تم تحديث البيانات بنجاح من رسالة جديدة")
        except Exception as e:
            logger.error(f"خطأ في معالجة الرسالة الجديدة: {e}")

# دالة رئيسية لتشغيل العميل
async def main():
    # إنشاء ملف البيانات الافتراضي إذا لم يكن موجوداً
    if not os.path.exists(EXCHANGE_RATES_FILE):
        save_data(DEFAULT_DATA)
    
    # إنشاء عميل التلغرام
    client = TelegramClient('syrian_lira_session', API_ID, API_HASH)
    
    try:
        # بدء العميل
        await client.start()
        
        # التحقق من تسجيل الدخول
        if not await client.is_user_authorized():
            await client.send_code_request(PHONE)
            try:
                await client.sign_in(PHONE, input('أدخل رمز التحقق: '))
            except SessionPasswordNeededError:
                await client.sign_in(password=input('أدخل كلمة المرور لحسابك: '))
        
        logger.info("تم تسجيل الدخول بنجاح")
        
        # معالجة الرسائل الموجودة
        await process_messages(client)
        
        # بدء مراقبة الرسائل الجديدة
        await monitor_new_messages(client)
        
        # الاستمرار في تشغيل العميل
        logger.info("بدء مراقبة الرسائل الجديدة...")
        await client.run_until_disconnected()
    except Exception as e:
        logger.error(f"خطأ في تشغيل العميل: {e}")
    finally:
        # إغلاق العميل
        await client.disconnect()

# دالة لتشغيل العميل في خلفية النظام
def run_client_in_background():
    import asyncio
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(main())

# دالة لتحديث البيانات دورياً (في حالة عدم توفر حساب تلغرام)
def update_periodically():
    import threading
    import time
    
    def update_thread():
        while True:
            try:
                # قراءة البيانات الحالية
                current_data = load_data()
                
                # إضافة تغييرات عشوائية للعملات (للعرض التجريبي فقط)
                import random
                
                for currency_code in current_data["currencies"]:
                    change = random.randint(-50, 50)
                    current_data["currencies"][currency_code]["sell"] += change
                    current_data["currencies"][currency_code]["buy"] += change
                    current_data["currencies"][currency_code]["sellChange"] = change
                    current_data["currencies"][currency_code]["buyChange"] = change
                
                # إضافة تغييرات عشوائية للذهب
                for gold_type in current_data["gold"]:
                    current_data["gold"][gold_type] += random.randint(-10000, 10000)
                
                # تحديث الطابع الزمني
                current_data["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                
                # حفظ البيانات المحدثة
                save_data(current_data)
                logger.info("تم تحديث البيانات دورياً")
            except Exception as e:
                logger.error(f"خطأ في التحديث الدوري: {e}")
            
            # انتظار 30 دقيقة قبل التحديث التالي
            time.sleep(30 * 60)
    
    # بدء خيط منفصل للتحديث الدوري
    update_thread = threading.Thread(target=update_thread)
    update_thread.daemon = True
    update_thread.start()

# نقطة الدخول الرئيسية
if __name__ == "__main__":
    # تحديد ما إذا كان سيتم استخدام عميل التلغرام أو التحديث الدوري
    USE_TELEGRAM_CLIENT = False  # تعيين إلى True لاستخدام عميل التلغرام
    
    if USE_TELEGRAM_CLIENT:
        # تشغيل عميل التلغرام في خلفية النظام
        import threading
        client_thread = threading.Thread(target=run_client_in_background)
        client_thread.daemon = True
        client_thread.start()
    else:
        # تشغيل التحديث الدوري
        update_periodically()
    
    # يمكن إضافة المزيد من الكود هنا إذا لزم الأمر
    
    # الاستمرار في تشغيل البرنامج
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        logger.info("تم إيقاف البرنامج")
